/***********************************************************/
/* commentController.js for week 08 Reading assignment     */
/* @author 		Dean Hall,                                  */
/* @version  	1.0                                        */
/* @date: 		2019-05                                    */
/*  CIT 261    Spring 2019 Semester                        */
/***********************************************************/
import CommentModel from './commentModel';

class CommentController{
   constructor(type, <?textBoxID?>) {


      
   }



}


export default CommentController;
