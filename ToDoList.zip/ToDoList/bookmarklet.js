(function() {
    console.log('starting...');
    alert("Hello! I am an alert box!");
    var elts = document.getElementsByTagName('p');
    for (var i = 0; i < elts.length; i++) {
      elts[i].style['background-color'] = '#C036F3';
    }
  })();

  