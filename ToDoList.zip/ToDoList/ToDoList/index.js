import todoController from "./todoController.js";

window.addEventListener('load', () => {
const mytodoController = new todoController('todoList');
mytodoController.addTodo();
console.log(mytodoController);

// toDoListElement.appendChild(createItem('Teach class'));
//     toDoListElement.appendChild(createItem('Listen to class'));

});

