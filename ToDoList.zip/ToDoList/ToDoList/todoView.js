
export const apikey = "abcdefghijk";
let itemList = [];
export const apiURL = "localhost:8000";

export default function createItem(data) {
    const item = document.createElement('li');
    item.innerHTML = `${data}`;
    return item;

}

