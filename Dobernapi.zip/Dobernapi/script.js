var ajaxhttp = new XMLHttpRequest();
var url = "data.json";

ajaxhttp.open("GET", url , true);
ajaxhttp.setRequestHeader("content-type","application/json");
ajaxhttp.onreadystatechange = function (){
    if(ajaxhttp.readyState === 4 && ajaxhttp.status === 200)
    {
        var jcontent = JSON.parse(ajaxhttp.responseText);
        console.log(jcontent);
        console.log(ajaxhttp);
    }
};
ajaxhttp.send(null);
//use fetch instead of xmlhtppreq
//look more into REST API

function loadDoc() {
    fetch('data.json')
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            appendData(data);
        })
        .catch(function (err) {
            console.log('error: ' + err);
        });

    function appendData(data) {
        var mainContainer = document.getElementById("myData");

        for (var i = 0; i < data.length; i++) {
            var div = document.createElement("div");
            div.innerHTML = "ID number " + data[i].id + " is " + data[i].first_name + ' ' + data[i].last_name + ". " + data[i].first_name + " was born on " + data[i].DOB + ".";
            mainContainer.appendChild(div);
        }
        console.log(data[0]); //Tyson
    }
}

function getIndividualData() {
    var selectedId = document.getElementById("options").selectedOptions[0].value; // e.g. "4" (string)
    fetch('data.json')
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            // let's filter the data
            var person = data.filter(function(p) { return p.id === parseInt(selectedId)});
            appendData(person);
        })
        .catch(function (err) {
            console.log('error: ' + err);
        });
}

function appendData(data) {
    var mainContainer = document.getElementById("myData");
    mainContainer.innerHTML = "";
    var div = document.createElement("pre");
    div.innerHTML = JSON.stringify(data, null, 4);
    mainContainer.appendChild(div);
}

function clearAnswer() {
    document.getElementById("myData").innerHTML = '';
}

