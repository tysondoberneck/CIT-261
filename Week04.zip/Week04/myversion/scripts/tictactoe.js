/******************/
/* js file        */
/******************/
/*****************************************************************/
/* tictactoe.js for week 04 Ponder assignment                    */
/* @author 		Dean Hall, Eric Okoro, Chris Hemming, Justin Hall */
/* @version  	1.0                                               */
/* @date: 		2019-04                                           */
/*  CIT 261    Spring 2019 Semester                              */
/*****************************************************************/

// need a function to initialize the board and starting player



function init() {


}